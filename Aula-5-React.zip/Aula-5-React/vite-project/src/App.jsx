import { useEffect, useState, useMemo} from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [nomes, setNomes] = useState([
    'Giovanna', 
    'Laura',
    'Giovanna Laura',
    'Gi']);

  const [input, setInput] = useState('');

  const totalAgenda = useMemo( () => nomes.length, {nomes})

function adicionar(){
  setNomes([...nomes, input]); // usando o spread para adicionar elementos no array
  setInput(" "); // limpando o campo do input 
}

// useEffect(funcao, array)
// enviando dados para serem armazenados temporariamente no Local Storage
useEffect(() => { 
  localStorage.setItem('agenda', JSON.stringify(nomes));
}, [nomes]) // stringfy converte um valor JavaScript em JSON 
 
// buscando dados no local storage
useEffect(() => {
  const nomesStorage = localStorage.getItem('agenda'); 
  if (nomesStorage) { 
    setNomes(JSON.parse(nomesStorage));
    }
}, []);

  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
       <ul>
        {nomes.map(nome => (<li key={nome}>{nome}</li>))}
       </ul>
      </div>
      <div>
        <h4>Total da Agenda: {totalAgenda} nomes.</h4>
      </div>
      <div className="card">
        <input type="text" value = {input} onChange = { e => setInput(e.target.value)}/>
        <button type="button" onClick = {adicionar}> Adicionar </button>
      </div>



    </>
  )
}

export default App
