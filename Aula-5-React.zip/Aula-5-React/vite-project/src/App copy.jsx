import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0);
  const [text, setText] = useState(" ");
  const [liked, setLiked] = useState(true);
  
  // essa chamada pode ser numérica, string ou função
  // const [nome, setNome] = useState("Gi"); // useState = estado inicial
  // const [funcao, setFuncao] = useState( () => criarLista() ); // é posivel iniciar um estado usando uma função

  function handleClick(){ // criando uma função para somar 1 no contador
    setCount(count => count + 1)
    // console.log(count);
    // setCount(count => count + 1)
    // console.log(count);
    // setCount(count => count + 1)
    // console.log(count);
  } 

  function handleChange(e) { // e passa tudo oque eu preciso
    console.log(e.target);
    setText(e.target.value);
  }

  function handleChangleLiked(e){
    setLiked(e.target.checked);
  }


  return (
    <>
      <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={handleClick}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
      </div>

      <div className="card">
        <input value = {text} onChange = {handleChange} />
        <p>Você digitou: {text}</p>
        <button onClick={ () => setText(" ")}>Limpar</button>
      </div>

      <div className="card">
        <label>
          <input type="checkbox" checked = {liked} onChange={handleChangleLiked}/> Eu gostei disso!
        </label>
        <p>Você {liked ? 'gostou' : 'não gostou'} disso.</p>  
      </div>

    </>
  )
}

export default App